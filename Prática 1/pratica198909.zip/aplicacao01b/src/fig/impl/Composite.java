/**
 * 
 */
package fig.impl;

import fig.interfaces.CompositeInterface;

/**
 * Classe concreta para representar figuras compostas.
 * @author Vladimir Oliveira Di Iorio
 */
public class Composite
extends FigList implements CompositeInterface {
}