package atividade3.interfaces;

public interface TreeIterator {

	boolean hasNext();
	TreeInterface next();
	
}
